package com.Jonathan.exam1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
