
$(document).ready( function() {
    
    // $("#main-heading").mouseenter(function () {
        
    // });


    // $("#main-heading").mouseleave(function () {
    //     console.log("leaving with jquery!!");
    //     console.log($("#main-heading").text("Vinson Aiono"));
    // });
    $("#main-heading").hover(
        function(){
            console.log("First func")
            console.log("text from heading: ");
            console.log($("#main-heading").text());
            $("#profile-pic").hide(1000);
            $(".projects").hide(1000);
        },
        function(){
            console.log("second func")
            console.log($("#main-heading").text());
            $("#profile-pic").show();
            $(".projects").show();
        }
    );


})


//                          event           event handler
document.addEventListener("DOMContentLoaded", function() {
    // ALL THE CODE YOU WANT TO RUN WHEN PAGE LOADS
    // console.log(document);
    // console.dir(document);
    // document.title = "New title of Page!!!";

    // var mainHeading = document.getElementById("main-heading");
    // console.dir(mainHeading);
    // //                                          callback
    // mainHeading.addEventListener("mouseenter", function() {
    //     console.log("Entering heading")
    //     mainHeading.style.color = "red";
    //     mainHeading.style.borderRadius = "5px";
    //     mainHeading.style.backgroundColor = "pink";
    // })

    // mainHeading.addEventListener("mouseleave", function() {
    //     console.log("leaving heading")
    //     mainHeading.style.color = "blue";
    //     mainHeading.style.border = "none";
    //     mainHeading.innerHTML = "Jayne Doe";
    //     mainHeading.style.backgroundColor = "white";
    // })
});

